package com.cognizant.nishi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditSeverityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
