package com.cognizant.nishi.service;

import java.util.List;

import com.cognizant.nishi.model.AuditBenchmark;
import com.cognizant.nishi.model.AuditQuestion;
import com.cognizant.nishi.model.AuditRequest;
import com.cognizant.nishi.model.AuditResponse;

public interface AuditResponseService {
	
	//public List<AuditResponse> getAuditResponses(List<AuditBenchmark> benchmarkList,List<AuditQuestion> questionListInternal,List<AuditQuestion> questionListSox);

	public AuditResponse getAuditResponse(List<AuditBenchmark> benchmarkList,
			String auditType, List<AuditQuestion> questionResponses);

	public AuditResponse saveAuditResponse(AuditResponse auditResponse, AuditRequest auditRequest); 
		
}
