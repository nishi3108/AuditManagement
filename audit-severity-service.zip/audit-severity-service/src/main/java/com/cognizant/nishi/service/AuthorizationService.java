package com.cognizant.nishi.service;


public interface AuthorizationService {
	
	public boolean validateJwt(String jwt);
}
