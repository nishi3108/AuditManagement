package com.cognizant.nishi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.nishi.model.AuditResponse;

public interface AuditResponseRepo extends JpaRepository<AuditResponse,Integer>{

}
