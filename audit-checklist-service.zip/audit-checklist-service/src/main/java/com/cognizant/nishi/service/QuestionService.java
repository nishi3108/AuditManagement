package com.cognizant.nishi.service;

import java.util.List;

import com.cognizant.nishi.model.AuditType;
import com.cognizant.nishi.model.Question;

public interface QuestionService {

	public List<Question> getQuestionsByAuditType(AuditType auditType);
}
